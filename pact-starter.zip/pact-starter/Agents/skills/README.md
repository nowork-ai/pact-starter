# Skills — Standardizovane workflow

> Skills kombinuji vice agentu do kompletni pipeline — od zadani po hotovy vystup.

## Co je Skill?

| Koncept | Otazka | Priklad |
|---------|--------|---------|
| **Skill** | Jak udelat cely ukol od A do Z? | "Vytvor landing page" (5 kroku, 4 agenti) |
| **Agent** | Jak udelat jednu specifickou cast? | "Napis hero text" (1 agent) |
| **Tool** | Cim to technicky provest? | "Prepis video" (1 skript) |

## Jak vytvorit Skill

1. Vytvor slozku: `Agents/skills/[nazev-skillu]/`
2. Vytvor `SKILL.md` s YAML frontmatter
3. Definuj pipeline, agenty, quality gates

## Format SKILL.md

```yaml
---
name: nazev-skillu
description: Co skill dela. Use when user says "trigger1", "trigger2".
---
```

Telo obsahuje: Pipeline, Agent Activation, Context Auto-Load, Quality Gates.
