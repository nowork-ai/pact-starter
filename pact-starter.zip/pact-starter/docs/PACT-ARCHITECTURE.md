# PACT — AI Workspace Architecture

> **P**rojects • **A**gents • **C**ontext • **T**ools
>
> Framework pro organizaci pracovniho prostoru pro efektivni spolupraci cloveka a AI.

---

## Filosofie

Pracovni prostor je rozdeleny do **ctyr zakladnich piliru**, z nichz kazdy odpovida na jinou otazku:

| Pilir | Otazka | Obsah |
|-------|--------|-------|
| **Projects** | CO delam? | Aktivni projekty s vystupy |
| **Agents** | JAK to udelat? | Instrukce pro AI agenty |
| **Context** | KDO to dela? | Identita, styl, expertiza, cile |
| **Tools** | CIM to udelat? | Nastroje, skripty, API |

---

## Klicove principy

1. **Single Source of Truth** — pravidla ziji na jednom miste (v `Context/`), agenti na ne odkazuji
2. **Agent = markdown soubor** — AI precte instrukce a samo rozhodne, jake nastroje pouzit
3. **Reference, ne hardcode** — agenti odkazuji na slozky, ne na konkretni soubory
4. **DRY** — zmena na jednom miste se projevi vsude
5. **AI je orchestrator** — AI cte agenta a samo najde potrebne nastroje

---

## Jak to funguje

```
Uzivatel: "Zpracuj toto video z podcastu"
    |
    v
AI cte: Projects/podcast/agent-podcast-processor.md
    |
    +---> Context/identity/tone-of-voice/
    |     (pro spravny styl vystupu)
    |
    +---> Tools/
    |     (najde potrebne nastroje)
    |
    +---> Vytvori vystupy podle workflow v agentovi
```

---

## Vazby mezi slozkami

```
        PROJECTS/
        (aktivni projekty)
            |
     Agent v projektu odkazuje na:
            |
     +------+------+
     |      |      |
  AGENTS/  TOOLS/ CONTEXT/
  (JAK)   (CIM)  (KDO)
```

- **Agent ≠ Tool:** Agent popisuje CO a JAK, tool dela konkretni operaci
- **Skill = Pipeline:** Skill orchestruje vice agentu do kompletniho workflow
- **AGENT-REGISTRY:** Centralni prehled vsech agentu = org chart systemu

---

*PACT Framework — vytvoril Filip Drimalka (nowork.ai)*
